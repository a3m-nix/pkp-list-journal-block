# PLUGINS OJS 3 List All Journal Block 
 Plugin OJS 3 untuk menampilkan semua jurnal di sidebar
